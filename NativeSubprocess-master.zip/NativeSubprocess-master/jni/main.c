#include <stdio.h>
#include <string.h>
#include <android/log.h>

#define LOGTAG "subprocess"
#define LOG_D(tag, msg) __android_log_write(ANDROID_LOG_DEBUG, tag, msg)

void exit_fn1(void) {
	LOG_D(LOGTAG, "1111111111111 oh dead!");
}

int main(int argc, char ** argv) {
	setsid();
	int pid = fork();
	if(pid < 0) {
		LOG_D(LOGTAG, "fork error b");
	}else if(pid == 0) {
		strcpy(argv[0], "t1a");
		while(1) {
			LOG_D(LOGTAG, "1111111111111 b");
			sleep(1);
		}
	}else {
		waitpid(pid, NULL, 0);
		LOG_D(LOGTAG, "fork pid dead b");
	}

	return 0;
}
