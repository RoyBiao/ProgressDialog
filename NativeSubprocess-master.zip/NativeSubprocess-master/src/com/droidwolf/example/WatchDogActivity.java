/*
 * Copyright (c) 2014 droidwolf(droidwolf2010@gmail.com)
 * All rights reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.droidwolf.example;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.util.TypedValue;
import android.view.Gravity;
import android.widget.TextView;

import com.droidwolf.nativesubprocess.Subprocess;

public class WatchDogActivity extends Activity {
	Handler mHandler = new Handler();

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setTitle("WatchDog");
		TextView tv = new TextView(this);
		tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 20);
		tv.setText("1,Automatic restart after 3 seconds to kill me\n"
				+ "2,I will lift uninstall the browser to display my blog");
		tv.setGravity(Gravity.CENTER);
		super.setContentView(tv);
		final String KEY = "previous_pid";
		final SharedPreferences spf = getSharedPreferences(getPackageName(),
				Context.MODE_PRIVATE);
		final int pid = spf.getInt(KEY, 0);
		
		String executable = "libtest.so";
		String aliasfile = "test";
		String parafind = "/data/data/" + getPackageName() + "/" + aliasfile;
		String r = RunExecutable(
				getPackageName(), executable, aliasfile,
				"com.qihoo.hellofork/.hostMonitor");
		Log.i("subprocess", r);
		//if(pid==0){
		//Subprocess.create(this, WatchDog.class);
		//Log.i("subprocess", "create watchdog");
		// }
		mHandler.post(new Runnable() {
			@Override
			public void run() {
				// TODO Auto-generated method stub

			}
		});
	}

	public String RunExecutable(String pacaageName, String filename,
			String alias, String args) {
		String path = "/data/data/" + pacaageName;
		String cmd1 = path + "/lib/" + filename;
		String cmd2 = path + "/" + alias;
		String cmd2_a1 = path + "/" + alias + " " + args;
		String cmd3 = "chmod 777 " + cmd2;
		String cmd4 = "dd if=" + cmd1 + " of=" + cmd2;
		StringBuffer sb_result = new StringBuffer();

		if (!new File("/data/data/" + alias).exists()) {
			RunLocalUserCommand(pacaageName, cmd4, sb_result); // 拷贝lib/libtest.so到上一层目录,同时命名为test.
			sb_result.append(";");
		}
		RunLocalUserCommand(pacaageName, cmd3, sb_result); // 改变test的属性,让其变为可执行
		sb_result.append(";");
		RunLocalUserCommand(pacaageName, cmd2_a1, sb_result); // 执行test程序.
		sb_result.append(";");
		return sb_result.toString();
	}

	public boolean RunLocalUserCommand(String pacaageName, String command,
			StringBuffer sb_out_Result) {
		Process process = null;
		try {
			
			process = Runtime.getRuntime().exec("sh"); // 获得shell进程
			DataInputStream inputStream = new DataInputStream(
					process.getInputStream());
			DataOutputStream outputStream = new DataOutputStream(
					process.getOutputStream());
			outputStream.writeBytes("cd /data/data/" + pacaageName + "\n"); // 保证在command在自己的数据目录里执行,才有权限写文件到当前目录

			outputStream.writeBytes(command + " &\n"); // 让程序在后台运行，前台马上返回
			outputStream.writeBytes("exit\n");
			outputStream.flush();
			process.waitFor();

			byte[] buffer = new byte[inputStream.available()];
			inputStream.read(buffer);
			String s = new String(buffer);
			if (sb_out_Result != null)
				sb_out_Result.append("CMD Result:\n" + s);
		} catch (Exception e) {
			if (sb_out_Result != null)
				sb_out_Result.append("Exception:" + e.getMessage());
			return false;
		}
		return true;
	}
}
